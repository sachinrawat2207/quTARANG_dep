import numpy as ncp
import pyfftw.interfaces.numpy_fft as pyfftw

def set_gpu(rank = 0):
    import cupy as ncp
    import cupy.fft as pyfftw
    dev = ncp.cuda.Device(para.device_rank)
    dev.use()
    # import cupy.core._accelerator as _acc
    # _acc.set_routine_accelerators(['cub'])
    # _acc.set_reduction_accelerators(['cub'])