import numpy as ncp
from gpe.set_device import *

 
class wfc():
    def __init__(self, params):
        """_summary_

        Parameters
        ----------
        params : dict, optional
            _description_, by default {'x': 1, 'y': 2, 'z' : 3}
        """
        self.x = ncp.arange(params['x'])
        self.y = ncp.arange(params['y'])
        self.z = ncp.arange(params['z'])
    

    
