# quTARANG

A Gross-Piatevskii equation solver written in python with support for both CPUs as well as GPUs. 
