from gpe.wfc import wfc
a = wfc()