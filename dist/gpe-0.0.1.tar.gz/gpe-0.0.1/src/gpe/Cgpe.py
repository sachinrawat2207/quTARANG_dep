import numpy as ncp
from gpe import wfc
