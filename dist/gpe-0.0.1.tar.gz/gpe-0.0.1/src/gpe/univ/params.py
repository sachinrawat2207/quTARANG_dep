import numpy as ncp
import pyfftw.interfaces.numpy_fft as pyfftw

def setgpu(device = 0):
    import cupy as ncp
    ncp.cuda.Device(device).use()
    import cupy.fft as pyfftw

