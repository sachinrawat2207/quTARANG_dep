[1] fns integral_k is now integralk
[2] fns integral_k takes grid as input instead of params.
[3] fns integral is now integralr